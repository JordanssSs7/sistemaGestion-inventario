package app;

import dao.ProductoDAO;
import dao.CategoriaDAO;
import dao.ProveedorDAO;
import dao.EntradaDAO;
import dao.SalidaDAO;
import model.Producto;
import model.Categoria;
import model.Proveedor;
import model.Entrada;
import model.Salida;
import model.DatabaseConnection;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

public class MainApp {
    private static final ProductoDAO productoDAO = new ProductoDAO();
    private static final CategoriaDAO categoriaDAO = new CategoriaDAO();
    private static final ProveedorDAO proveedorDAO = new ProveedorDAO();
    private static final EntradaDAO entradaDAO = new EntradaDAO();
    private static final SalidaDAO salidaDAO = new SalidaDAO();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion = -1;
        do {
            mostrarMenu();
            if (scanner.hasNextInt()) {
                opcion = scanner.nextInt();
                scanner.nextLine();
            } else {
                System.out.println("Entrada no válida. Ingrese un número.");
                scanner.nextLine();
                opcion = -1;
                continue;
            }
            switch (opcion) {
                case 1:
                    mostrarInventario();
                    break;
                case 2:
                    insertarNuevoProducto();
                    break;
                case 3:
                    mostrarCategorias();
                    break;
                case 4:
                    insertarNuevaCategoria();
                    break;
                case 5:
                    actualizarCategoria();
                    break;
                case 6:
                    eliminarCategoria();
                    break;
                case 7:
                    mostrarProveedores();
                    break;
                case 8:
                    insertarNuevoProveedor();
                    break;
                case 9:
                    mostrarEntradas();
                    break;
                case 10:
                    insertarNuevaEntrada();
                    break;
                case 11:
                    mostrarSalidas();
                    break;
                case 12:
                    insertarNuevaSalida();
                    break;
                case 0:
                    System.out.println("Saliendo del Sistema Básico de Gestión de Inventario...");
                    break;
                default:
                    System.out.println("Opción no reconocida. Intente de nuevo.");
            }
        } while (opcion != 0);

        DatabaseConnection.closeConnection();
        scanner.close();
    }

    private static void mostrarMenu() {
        System.out.println("\n--- MENU DE INVENTARIO (SBGI) ---");
        System.out.println("1. Ver Inventario Completo");
        System.out.println("2. Agregar Nuevo Producto");
        System.out.println("3. Ver Categorías");
        System.out.println("4. Agregar Nueva Categoría");
        System.out.println("5. Actualizar Categoría");
        System.out.println("6. Eliminar Categoría");
        System.out.println("7. Ver Proveedores");
        System.out.println("8. Agregar Nuevo Proveedor");
        System.out.println("9. Ver Entradas");
        System.out.println("10. Agregar Nueva Entrada");
        System.out.println("11. Ver Salidas");
        System.out.println("12. Agregar Nueva Salida");
        System.out.println("0. Salir");
        System.out.print("Seleccione una opción: ");
    }

    // === Métodos Producto ===
    private static void mostrarInventario() {
        System.out.println("\n--- INVENTARIO DE PRODUCTOS ---");
        List<Producto> inventario = productoDAO.obtenerTodos();

        if (inventario.isEmpty()) {
            System.out.println("No hay productos registrados en el inventario.");
        } else {
            System.out.println("===============================================================");
            System.out.printf("%-5s | %-30s | %-10s | %s%n", "ID", "NOMBRE", "STOCK", "PRECIO UNITARIO");
            System.out.println("---------------------------------------------------------------");
            for (Producto p : inventario) {
                System.out.println(p);
            }
            System.out.println("===============================================================");
        }
    }

    private static void insertarNuevoProducto() {
        System.out.println("\n--- AGREGAR NUEVO PRODUCTO ---");
        System.out.print("Nombre del Producto: ");
        String nombre = scanner.nextLine();
        System.out.print("Stock Inicial: ");
        int stock = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Precio Unitario: ");
        double precio = scanner.nextDouble();
        scanner.nextLine();

        Producto nuevoProducto = new Producto(nombre, stock, precio);
        boolean insertado = productoDAO.insertar(nuevoProducto);

        if (insertado) {
            System.out.println("Producto agregado con éxito!");
        } else {
            System.out.println("ERROR al intentar agregar el producto.");
        }
    }

    // === Métodos Categoría ===
    private static void mostrarCategorias() {
        List<Categoria> categorias = categoriaDAO.obtenerTodas();
        if (categorias.isEmpty()) {
            System.out.println("No hay categorías registradas.");
        } else {
            System.out.println("ID   | NOMBRE");
            for (Categoria c : categorias) {
                System.out.println(c);
            }
        }
    }

    private static void insertarNuevaCategoria() {
        System.out.print("ID de la nueva categoría: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nombre de la nueva categoría: ");
        String nombre = scanner.nextLine();
        Categoria nueva = new Categoria(id, nombre);
        boolean exito = categoriaDAO.insertar(nueva);
        System.out.println(exito ? "Categoría agregada con éxito!" : "Error al agregar la categoría.");
    }

    private static void actualizarCategoria() {
        System.out.print("ID de la categoría a actualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nuevo nombre de la categoría: ");
        String nombre = scanner.nextLine();
        Categoria mod = new Categoria(id, nombre);
        boolean exito = categoriaDAO.actualizar(mod);
        System.out.println(exito ? "Categoría actualizada!" : "No se pudo actualizar la categoría.");
    }

    private static void eliminarCategoria() {
        System.out.print("ID de la categoría a eliminar: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        boolean exito = categoriaDAO.eliminar(id);
        System.out.println(exito ? "Categoría eliminada!" : "No se pudo eliminar la categoría.");
    }

    // === Métodos Proveedor ===
    private static void mostrarProveedores() {
        List<Proveedor> proveedores = proveedorDAO.obtenerTodos();
        if (proveedores.isEmpty()) {
            System.out.println("No hay proveedores registrados.");
        } else {
            System.out.println("ID   | NOMBRE                         | CONTACTO");
            for (Proveedor p : proveedores) {
                System.out.println(p);
            }
        }
    }

    private static void insertarNuevoProveedor() {
        System.out.print("ID del nuevo proveedor: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Nombre del nuevo proveedor: ");
        String nombre = scanner.nextLine();
        System.out.print("Contacto del nuevo proveedor: ");
        String contacto = scanner.nextLine();
        Proveedor nuevo = new Proveedor(id, nombre, contacto);
        boolean exito = proveedorDAO.insertar(nuevo);
        System.out.println(exito ? "Proveedor agregado con éxito!" : "Error al agregar el proveedor.");
    }

    // === Métodos Entrada ===
    private static void mostrarEntradas() {
        List<Entrada> entradas = entradaDAO.obtenerTodas();
        if (entradas.isEmpty()) {
            System.out.println("No hay entradas registradas.");
        } else {
            System.out.println("ID    | FECHA       | ID_PROD | CANTIDAD | PRECIO_COMPRA");
            for (Entrada e : entradas) {
                System.out.println(e);
            }
        }
    }

    private static void insertarNuevaEntrada() {
        System.out.print("ID de la nueva entrada: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Fecha (YYYY-MM-DD): ");
        String fechaStr = scanner.nextLine();
        Date fecha = Date.valueOf(fechaStr);
        System.out.print("ID del producto: ");
        int idProducto = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Cantidad: ");
        int cantidad = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Precio de compra: ");
        double precioCompra = scanner.nextDouble();
        scanner.nextLine();
        Entrada nueva = new Entrada(id, fecha, idProducto, cantidad, precioCompra);
        boolean exito = entradaDAO.insertar(nueva);
        System.out.println(exito ? "Entrada agregada con éxito!" : "Error al agregar la entrada.");
    }

    // === Métodos Salida ===
    private static void mostrarSalidas() {
        List<Salida> salidas = salidaDAO.obtenerTodas();
        if (salidas.isEmpty()) {
            System.out.println("No hay salidas registradas.");
        } else {
            System.out.println("ID    | FECHA       | ID_PROD | CANTIDAD | PRECIO_VENTA");
            for (Salida s : salidas) {
                System.out.println(s);
            }
        }
    }

    private static void insertarNuevaSalida() {
        System.out.print("ID de la nueva salida: ");
        int id = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Fecha (YYYY-MM-DD): ");
        String fechaStr = scanner.nextLine();
        Date fecha = Date.valueOf(fechaStr);
        System.out.print("ID del producto: ");
        int idProducto = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Cantidad: ");
        int cantidad = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Precio de venta: ");
        double precioVenta = scanner.nextDouble();
        scanner.nextLine();
        Salida nueva = new Salida(id, fecha, idProducto, cantidad, precioVenta);
        boolean exito = salidaDAO.insertar(nueva);
        System.out.println(exito ? "Salida agregada con éxito!" : "Error al agregar la salida.");
    }
}
