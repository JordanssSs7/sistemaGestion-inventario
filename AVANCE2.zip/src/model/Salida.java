package model;

import java.sql.Date;

public class Salida {
    private int idSalida;
    private Date fecha;
    private int idProducto;
    private int cantidad;
    private double precioVenta;

    public Salida(int idSalida, Date fecha, int idProducto, int cantidad, double precioVenta) {
        this.idSalida = idSalida;
        this.fecha = fecha;
        this.idProducto = idProducto;
        this.cantidad = cantidad;
        this.precioVenta = precioVenta;
    }
    public Salida(Date fecha, int idProducto, int cantidad, double precioVenta) {
        this.fecha = fecha;
        this.idProducto = idProducto;
        this.cantidad = cantidad;
        this.precioVenta = precioVenta;
    }
    public int getIdSalida() { return idSalida; }
    public Date getFecha() { return fecha; }
    public int getIdProducto() { return idProducto; }
    public int getCantidad() { return cantidad; }
    public double getPrecioVenta() { return precioVenta; }
    public void setIdSalida(int idSalida) { this.idSalida = idSalida; }
    public void setFecha(Date fecha) { this.fecha = fecha; }
    public void setIdProducto(int idProducto) { this.idProducto = idProducto; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public void setPrecioVenta(double precioVenta) { this.precioVenta = precioVenta; }
    @Override
    public String toString() {
        return String.format("%-5d | %-12s | %-7d | %-7d | $%.2f",
                idSalida, fecha, idProducto, cantidad, precioVenta);
    }
}

