package model;

public class Proveedor {
    private int idProveedor;
    private String nombre;
    private String contacto;

    public Proveedor(int idProveedor, String nombre, String contacto) {
        this.idProveedor = idProveedor;
        this.nombre = nombre;
        this.contacto = contacto;
    }
    public Proveedor(String nombre, String contacto) {
        this.nombre = nombre;
        this.contacto = contacto;
    }
    public int getIdProveedor() { return idProveedor; }
    public String getNombre() { return nombre; }
    public String getContacto() { return contacto; }
    public void setIdProveedor(int idProveedor) { this.idProveedor = idProveedor; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setContacto(String contacto) { this.contacto = contacto; }
    @Override
    public String toString() {
        return String.format("%-5d | %-30s | %-20s", idProveedor, nombre, contacto);
    }
}

