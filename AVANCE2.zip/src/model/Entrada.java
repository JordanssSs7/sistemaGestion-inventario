package model;

import java.sql.Date;

public class Entrada {
    private int idEntrada;
    private Date fecha;
    private int idProducto;
    private int cantidad;
    private double precioCompra;

    public Entrada(int idEntrada, Date fecha, int idProducto, int cantidad, double precioCompra) {
        this.idEntrada = idEntrada;
        this.fecha = fecha;
        this.idProducto = idProducto;
        this.cantidad = cantidad;
        this.precioCompra = precioCompra;
    }
    public Entrada(Date fecha, int idProducto, int cantidad, double precioCompra) {
        this.fecha = fecha;
        this.idProducto = idProducto;
        this.cantidad = cantidad;
        this.precioCompra = precioCompra;
    }
    public int getIdEntrada() { return idEntrada; }
    public Date getFecha() { return fecha; }
    public int getIdProducto() { return idProducto; }
    public int getCantidad() { return cantidad; }
    public double getPrecioCompra() { return precioCompra; }
    public void setIdEntrada(int idEntrada) { this.idEntrada = idEntrada; }
    public void setFecha(Date fecha) { this.fecha = fecha; }
    public void setIdProducto(int idProducto) { this.idProducto = idProducto; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    public void setPrecioCompra(double precioCompra) { this.precioCompra = precioCompra; }
    @Override
    public String toString() {
        return String.format("%-5d | %-12s | %-7d | %-7d | $%.2f",
                idEntrada, fecha, idProducto, cantidad, precioCompra);
    }
}

