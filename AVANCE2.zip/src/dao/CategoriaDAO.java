package dao;

import model.Categoria;
import model.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CategoriaDAO {
    public List<Categoria> obtenerTodas() {
        List<Categoria> categorias = new ArrayList<>();
        String sql = "SELECT ID_CATEGORIA, NOMBRE FROM CATEGORIAS ORDER BY ID_CATEGORIA";
        try (Connection con = DatabaseConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                int id = rs.getInt("ID_CATEGORIA");
                String nombre = rs.getString("NOMBRE");
                categorias.add(new Categoria(id, nombre));
            }
        } catch (SQLException e) {
            System.err.println("ERROR DAO: Falló la consulta SELECT categoría.");
            e.printStackTrace();
        }
        return categorias;
    }
    public boolean insertar(Categoria categoria) {
        String sql = "INSERT INTO CATEGORIAS (ID_CATEGORIA, NOMBRE) VALUES (?, ?)";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, categoria.getIdCategoria()); // O generar con secuencia si defines una
            ps.setString(2, categoria.getNombre());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            System.err.println("ERROR DAO: Falló el INSERT de categoría.");
            e.printStackTrace();
            return false;
        }
    }
    public boolean actualizar(Categoria categoria) {
        String sql = "UPDATE CATEGORIAS SET NOMBRE = ? WHERE ID_CATEGORIA = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, categoria.getNombre());
            ps.setInt(2, categoria.getIdCategoria());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            System.err.println("ERROR DAO: Falló el UPDATE de categoría.");
            e.printStackTrace();
            return false;
        }
    }
    public boolean eliminar(int idCategoria) {
        String sql = "DELETE FROM CATEGORIAS WHERE ID_CATEGORIA = ?";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idCategoria);
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            System.err.println("ERROR DAO: Falló el DELETE de categoría.");
            e.printStackTrace();
            return false;
        }
    }
}

