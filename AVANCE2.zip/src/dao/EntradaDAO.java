package dao;

import model.Entrada;
import model.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EntradaDAO {
    public List<Entrada> obtenerTodas() {
        List<Entrada> entradas = new ArrayList<>();
        String sql = "SELECT ID_ENTRADA, FECHA, ID_PRODUCTO, CANTIDAD, PRECIO_COMPRA FROM ENTRADAS ORDER BY ID_ENTRADA";
        try (Connection con = DatabaseConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                int id = rs.getInt("ID_ENTRADA");
                Date fecha = rs.getDate("FECHA");
                int idProducto = rs.getInt("ID_PRODUCTO");
                int cantidad = rs.getInt("CANTIDAD");
                double precio = rs.getDouble("PRECIO_COMPRA");
                entradas.add(new Entrada(id, fecha, idProducto, cantidad, precio));
            }
        } catch (SQLException e) {
            System.err.println("ERROR DAO: Falló la consulta SELECT entrada.");
            e.printStackTrace();
        }
        return entradas;
    }

    public boolean insertar(Entrada entrada) {
        String sql = "INSERT INTO ENTRADAS (ID_ENTRADA, FECHA, ID_PRODUCTO, CANTIDAD, PRECIO_COMPRA) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, entrada.getIdEntrada());
            ps.setDate(2, entrada.getFecha());
            ps.setInt(3, entrada.getIdProducto());
            ps.setInt(4, entrada.getCantidad());
            ps.setDouble(5, entrada.getPrecioCompra());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            System.err.println("ERROR DAO: Falló el INSERT de entrada.");
            e.printStackTrace();
            return false;
        }
    }
}
