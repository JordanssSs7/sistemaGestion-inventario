package dao;

import model.Salida;
import model.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SalidaDAO {
    public List<Salida> obtenerTodas() {
        List<Salida> salidas = new ArrayList<>();
        String sql = "SELECT ID_SALIDA, FECHA, ID_PRODUCTO, CANTIDAD, PRECIO_VENTA FROM SALIDAS ORDER BY ID_SALIDA";
        try (Connection con = DatabaseConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                int id = rs.getInt("ID_SALIDA");
                Date fecha = rs.getDate("FECHA");
                int idProducto = rs.getInt("ID_PRODUCTO");
                int cantidad = rs.getInt("CANTIDAD");
                double precio = rs.getDouble("PRECIO_VENTA");
                salidas.add(new Salida(id, fecha, idProducto, cantidad, precio));
            }
        } catch (SQLException e) {
            System.err.println("ERROR DAO: Falló la consulta SELECT salida.");
            e.printStackTrace();
        }
        return salidas;
    }

    public boolean insertar(Salida salida) {
        String sql = "INSERT INTO SALIDAS (ID_SALIDA, FECHA, ID_PRODUCTO, CANTIDAD, PRECIO_VENTA) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, salida.getIdSalida());
            ps.setDate(2, salida.getFecha());
            ps.setInt(3, salida.getIdProducto());
            ps.setInt(4, salida.getCantidad());
            ps.setDouble(5, salida.getPrecioVenta());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            System.err.println("ERROR DAO: Falló el INSERT de salida.");
            e.printStackTrace();
            return false;
        }
    }
}
