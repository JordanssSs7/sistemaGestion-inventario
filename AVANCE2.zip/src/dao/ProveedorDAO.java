package dao;

import model.Proveedor;
import model.DatabaseConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProveedorDAO {
    public List<Proveedor> obtenerTodos() {
        List<Proveedor> proveedores = new ArrayList<>();
        String sql = "SELECT ID_PROVEEDOR, NOMBRE, CONTACTO FROM PROVEEDORES ORDER BY ID_PROVEEDOR";
        try (Connection con = DatabaseConnection.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                int id = rs.getInt("ID_PROVEEDOR");
                String nombre = rs.getString("NOMBRE");
                String contacto = rs.getString("CONTACTO");
                proveedores.add(new Proveedor(id, nombre, contacto));
            }
        } catch (SQLException e) {
            System.err.println("ERROR DAO: Falló la consulta SELECT proveedor.");
            e.printStackTrace();
        }
        return proveedores;
    }

    public boolean insertar(Proveedor proveedor) {
        String sql = "INSERT INTO PROVEEDORES (ID_PROVEEDOR, NOMBRE, CONTACTO) VALUES (?, ?, ?)";
        try (Connection con = DatabaseConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, proveedor.getIdProveedor());
            ps.setString(2, proveedor.getNombre());
            ps.setString(3, proveedor.getContacto());
            int filasAfectadas = ps.executeUpdate();
            return filasAfectadas > 0;
        } catch (SQLException e) {
            System.err.println("ERROR DAO: Falló el INSERT de proveedor.");
            e.printStackTrace();
            return false;
        }
    }
    // Puedes agregar actualizar y eliminar siguiendo el mismo patrón
}
